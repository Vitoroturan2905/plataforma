import Fotinha from './Fotinha';
import './Timeline.css';
import { FiHome } from 'react-icons/fi';
import { BsThreeDots } from 'react-icons/bs';
import { BsSuitHeart } from 'react-icons/bs';
import Imagem from './Imagem';
import Sugestoes from '../sugest/Sugestoes';
import Fotinha3 from './Fotinha3';


function Timeline3 (){
    return(
        
        <div className='geral_timeline'>
            <Fotinha3 icone={<BsThreeDots />} />
            
    

        </div>
       
    )
}
export default Timeline3;