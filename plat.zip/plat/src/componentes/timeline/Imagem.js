function Imagem(props){
    return(
        <div className="curtidas">
              <span className="icone1">{props.icone}</span>

              
        </div>
    )
}

export default Imagem;