function Pesquisar (props){
    return(
        

                <div className="text">
                    <form>
                    <input className="barra_pesquisar" type={Text} placeholder="Pesquisar"></input>
                    </form>
                    

                    
                </div>
                
        
    )
}

export default Pesquisar;